0.0.3 (2015-03-26)
==================

* Scoped Authentication support

0.0.2
=====

* Bug fixes

0.0.1
=====

* Initial commit
